<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path class="change-stroke" d="M21.5 14.5V10V6C21.5 5.44772 21.0523 5 20.5 5H16.5H8H4C3.44772 5 3 5.44772 3 6V10V17V18.5C3 19.0523 3.44772 19.5 4 19.5H8H11H14" stroke="#414346" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
    <path class="change-stroke" d="M21 17L17 20.991L21 17ZM17 17.009L21 21L17 17.009Z" fill="#414346" />
    <path class="change-stroke" d="M21 17L17 20.991M17 17.009L21 21" stroke="#414346" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" />
    <path class="change-stroke" d="M21.5 13.9998L18.0305 11.4612C17.66 11.1901 17.1525 11.2061 16.7998 11.5L14.5016 13.4152C14.1042 13.7463 13.52 13.7198 13.1543 13.3541L8.50711 8.70696C8.11658 8.31643 7.48342 8.31643 7.09289 8.70696L3 12.7998" stroke="#414346" stroke-width="1.5" />
    <circle cx="16" cy="8" r="1" fill="#414346" />
</svg>