<div class="modal fade" id="question" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title">Show In Mobile Pannel</div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <div class="card p-3" style="min-width: 100%;">
                    <div class="thumbnail-gallery my-auto">
                        <a class="img-thumbnail w-100 my-auto" href="<?php echo $img_example ?>" data-plugin-options='{ "type":"image" }'>
                            <img class="img-responsive w-100" src="<?php echo $img_example ?>">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>